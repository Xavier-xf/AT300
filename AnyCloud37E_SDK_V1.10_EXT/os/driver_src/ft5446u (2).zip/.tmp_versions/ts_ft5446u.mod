/home/share/meiou/sdk_indoor/os/driver_src/ft5446u/ts_ft5446u.ko
/home/share/meiou/sdk_indoor/os/driver_src/ft5446u/ft5446u.o
